
// Component Base class
#include <execution/GenericTaskContext.hpp>
#include <execution/Ports.hpp>
#include <execution/TemplateFactories.hpp>
// Orocos command line
#include <execution/TaskBrowser.hpp>
// Non periodic task.
#include <corelib/NonPeriodicActivity.hpp>
// Periodic task.
#include <corelib/PreemptibleActivity.hpp>
#include <corelib/MultiVector.hpp>
#include <os/main.h>

#include "geometry/frames.h"
#include "KinematicsComponent.hpp"

using namespace ORO_Execution;
using namespace ORO_CoreLib;
using namespace ORO_Geometry;
using namespace Orocos;

struct Image
{
    char*  data;
    double time_stamp;
};

/**
 * Fetches images from a Camera Device.
 */
struct CameraComponent
    : public GenericTaskContext
{
    // Data Flow Port:
    WriteDataPort<Image> outport;

    /**
     * Method:
     */
    Image getImage() {
        Image im;
        // fetch image from camera
        // im = ...
        im.time_stamp = last_fetched + 1;

        if ( outport.connected() ) {
            outport.data()->Set( im );
        }
        ++last_fetched;
        
        return im;
    }

    /**
     * Command:
     */
    bool fetchImage() {
        if ( !outport.connected() ) 
            return false;
        
        this->getImage();
        return true;
    }

    /**
     * Command's completion condition:
     */
    bool imageFetched() const {
        if ( !outport.connected() ) 
            return false;
        return last_fetched == outport.data()->Get().time_stamp;
    }

    CameraComponent(std::string name = "Camera")
        : GenericTaskContext(name),
          outport("Image"),
          last_fetched(0)
    {
        // Add a Port to the Data Flow Interface:
        this->ports()->addPort( &outport );


        // Add a Method to the Method Interface:
        TemplateMethodFactory<CameraComponent>* mfact = newMethodFactory(this);

        mfact->add( "getImage", method(&CameraComponent::getImage,
                    "Get a new image from the camera and write it to the 'Image' port."));

        this->methods()->registerObject("this", mfact );


        // Add a Command to the Command Interface:
        TemplateCommandFactory<CameraComponent>* cfact = newCommandFactory(this);

        cfact->add( "fetchImage", command(&CameraComponent::fetchImage, &CameraComponent::imageFetched, 
                    "Get a new image from the camera and write it to the 'Image' port."));

        this->commands()->registerObject("this", cfact );
    }

protected:
    // time-stamp of last fetched image.
    double last_fetched;
};

struct CarLocation
{
    double x,y;
};

/**
 * Calculates Car Location from Camera Image.
 */
struct RecognitionComponent
    : public GenericTaskContext
{
    // Data Flow ports:
    ReadDataPort<Image> inport;
    WriteBufferPort<CarLocation> outport;

    // Properties:
    Property<std::string> car_color;
    Property<int> img_size;

    // Peer methods:
    MethodC getImage;

    RecognitionComponent(std::string name = "Recognition")
        : GenericTaskContext(name),
          inport("Image"),
          outport("Location",10),
          car_color("CarColor","Color to recognise (one of:Red,Blue,Green).", "Red"),
          img_size("ImageSize","Size of the image in KiloBytes.", 640*400)
    {
        this->ports()->addPort( &inport );
        this->ports()->addPort( &outport );

        this->properties()->addProperty( &car_color );
        this->properties()->addProperty( &img_size );
    }

    /**
     * Define the conditions under which a startup is valid.
     */
    bool startup()
    {
        if ( this->getPeer("Camera") ) {
            // create method object:
            getImage = this->getPeer("Camera")->methods()->create("this","getImage");
        }
        return inport.connected() && outport.connected();
    }

    /**
     * User's periodic function
     */
    void update()
    {
        // invoke method object
        getImage.execute();

        Image im = inport.data()->Get();

        // find location...
        CarLocation cl;

        outport.write()->Push( cl );
    }

    /**
     * Cleanup if necessary.
     */
    void shutdown()
    {
    }
};

struct CarHeading
{
    double x,y;
    double xdot, ydot;
};

/**
 * Dummy Filter
 */
struct KalmanFilter
    : public GenericTaskContext
{
    ReadBufferPort<CarLocation> inport;
    WriteBufferPort<CarHeading> outport;

    CarHeading ch;

    KalmanFilter(std::string name = "Filter")
        : GenericTaskContext(name),
          inport("Location"),
          outport("SetPoint",10)
    {
        this->ports()->addPort( &inport);
        this->ports()->addPort( &outport);
    }

    bool startup()
    {
        return inport.connected() && outport.connected();
    }

    void update()
    {
        // calculate heading of Car...
        CarLocation cl;
        if ( inport.read()->Pop(cl) ) {
            // new data available, system update !
        } else {
            // extrapolate further with old data
        }
        outport.write()->Push( ch );
    }
};

struct TrajectoryGenerator
    : public GenericTaskContext
{
    WriteDataPort<ORO_KinDyn::JointVelocities> outport;
    ReadDataPort<ORO_KinDyn::JointPositions> inport;

    TrajectoryGenerator(std::string name="Generator")
        : GenericTaskContext(name),
          outport("JointVel",ORO_KinDyn::JointVelocities(6) ),
          inport("JointPos")
    {
        this->ports()->addPort( &outport);
        this->ports()->addPort( &inport);
        
        TemplateCommandFactory<TrajectoryGenerator>* cfact
            = newCommandFactory(this);
        cfact->add("moveTo",command(&TrajectoryGenerator::moveTo,
                                    &TrajectoryGenerator::isAt,
                                    "Move in Cartesian space.",
                                    "p","Target position.",
                                    "t","Move time."));
        cfact->add("moveJoints",command(&TrajectoryGenerator::moveJoints,
                                        &TrajectoryGenerator::jointsAt,
                                        "Move in joint space.",
                                        "q6","Target position.",
                                        "t","Move time."));
        cfact->add("safeStop", command(&TrajectoryGenerator::safeStop,
                                       &TrajectoryGenerator::isStopped,
                                       "Safely stop the ongoing movement."));
        this->commands()->registerObject("this",cfact);
    }

    bool moveTo(Frame p, double t)
    {
        return true;
    }

    bool isAt(Frame p) const 
    {
        return true;
    }

    bool moveJoints(Double6D j6, double t)
    {
        return true;
    }

    bool jointsAt(Double6D j6) const
    {
        return true;
    }

    bool safeStop() {
        return true;
    }

    bool isStopped() const {
        return true;
    }

};

struct TrajectoryInterpolator
    : public GenericTaskContext
{
    ReadBufferPort<CarHeading> inport;
    ReadDataPort<ORO_KinDyn::JointPositions> qpos;
    WriteDataPort<ORO_KinDyn::JointVelocities> outport;

    Event<void(double)> distance;
    Attribute<double> d;

    TrajectoryInterpolator(std::string name="Interpolator")
        : GenericTaskContext(name),
          inport("SetPoint"),
          qpos("JointPos"),
          outport("JointVel",ORO_KinDyn::JointVelocities(6) )
    {
        this->ports()->addPort( &inport);
        this->ports()->addPort( &outport);
        this->ports()->addPort( &qpos);

        this->events()->addEvent("CarDistance",&distance);

        // Use an attribute to simulate distance to Car.
        this->attributes()->addAttribute("d", &d);
    }

    void update()
    {
        distance.emit( d.get() );
    }
    
};

struct Gripper
    : public GenericTaskContext
{
    Event<void(void)> objectGrasped;

    Property<Frame> frame;

    bool open_closed;

    Gripper(std::string name="Gripper")
        : GenericTaskContext(name),
          frame("ToolFrame","Mounting-plate to Tool End-Point frame.", Frame::Identity() ),
          open_closed(false)
    {
        TemplateCommandFactory<Gripper>* cfact
            = newCommandFactory(this);
        cfact->add("close",command(&Gripper::close,
                                    &Gripper::isClosed,
                                    "Close the gripper."));
        cfact->add("open",command(&Gripper::open,
                                  &Gripper::isOpen,
                                  "Open the gripper."));
        this->commands()->registerObject("this",cfact);

        TemplateMethodFactory<Gripper>* mfact = newMethodFactory(this);
        mfact->add( "getFrame", method(&Gripper::getFrame,
                    "Get the mounting-plate to tool end-point frame."));
        mfact->add( "isOpen", method(&Gripper::isOpen,
                    "Is the gripper open ?"));
        this->methods()->registerObject("this", mfact );

        this->events()->addEvent("CarGrasped",&objectGrasped);

        this->properties()->addProperty( &frame );
    }

    Frame getFrame() {
        return frame;
    }

    bool close()
    {
        objectGrasped.emit();
        open_closed = false;
        return true;
    }

    bool isClosed() const 
    {
        return !open_closed;
    }

    bool open()
    {
        open_closed = true;
        return true;
    }

    bool isOpen() const
    {
        return open_closed;
    }
};

struct Robot
    : public GenericTaskContext
{
    Property<Frame> hframe;

    WriteDataPort< ORO_KinDyn::JointPositions > qpos;
    ReadDataPort< ORO_KinDyn::JointVelocities > qdot;

    Robot(std::string name="Robot")
        : GenericTaskContext(name),
          hframe("HomingFrame","Homing position", Frame::Identity() ),
          qpos("JointPos",ORO_KinDyn::JointVelocities(6) ),
          qdot("JointVel")
    {
        this->ports()->addPort( &qpos );
        this->ports()->addPort( &qdot );

        this->properties()->addProperty( &hframe );

        hframe.set().p = Vector(0.0,0.5,1.0);
        hframe.set().M = Rotation::Identity();
    }
};


int ORO_main(int argc, char** argv)
{
    CameraComponent cc;
    RecognitionComponent rc;
    KalmanFilter kf;
    TrajectoryGenerator tg;
    TrajectoryInterpolator ti;
    KinematicsComponent kp("Kinematics");
    Gripper grip;
    Robot rob;

    GenericTaskContext application("Application");

    cc.connectPeers( &rc );
    rc.addPeer( &kf );
    kf.addPeer( &ti );

    tg.addPeer( &kp );
    ti.addPeer( &kp );
    kp.addPeer( &grip );

    tg.connectPeers( &rob );
    ti.connectPeers( &rob );
    kp.connectPeers( &rob );

    // application logic.
    application.addPeer( &cc );
    application.addPeer( &rc );
    application.addPeer( &kf );
    application.addPeer( &tg );
    application.addPeer( &ti );
    application.addPeer( &kp );
    application.addPeer( &grip );
    application.addPeer( &rob );

    NonPeriodicActivity cctask( 25, cc.engine() );
    PreemptibleActivity rctask( 0.1, rc.engine() );
    PreemptibleActivity kftask( 0.1, kf.engine() );
    PreemptibleActivity tgtask( 0.05, tg.engine() );
    PreemptibleActivity titask( 0.05, ti.engine() );
    PreemptibleActivity robtask( 0.05, rob.engine() );
    NonPeriodicActivity griptask( 25, grip.engine() );

    PreemptibleActivity apptask( 0.1, application.engine() );

    Event<void(void)> safeStopEvent;
    application.events()->addEvent( "SafeStopEvent", &safeStopEvent );

    TaskBrowser tb(&application);
    
    tb.loop();

    return 0;
}
